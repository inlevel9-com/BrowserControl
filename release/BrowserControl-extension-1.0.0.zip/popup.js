// src/popup.ts
var $ = (id) => document.getElementById(id);
function render(s) {
  const dot = $("dot");
  dot.className = `dot ${s.state === "connected" && s.handshake ? "connected" : s.state}`;
  $("state").textContent = s.state === "connected" && s.handshake ? `connected \xB7 v${s.version}` : s.state === "connected" ? "handshaking\u2026" : s.state;
  $("enabled").toggleAttribute("checked", !!s.settings?.enabled);
  $("enabled").checked = !!s.settings?.enabled;
  if (document.activeElement !== $("port")) $("port").value = String(s.settings?.port ?? "");
  if (document.activeElement !== $("label")) $("label").value = s.settings?.label ?? "";
  const procName = s.handshake?.process?.browser ?? s.handshake?.process?.name;
  $("browser").textContent = `${procName ? `${procName} (via daemon)` : s.browser.name} \xB7 Chromium ${s.browser.version}`;
  $("instance").textContent = s.settings?.instanceId ?? "";
  $("daemon").textContent = s.handshake ? `${s.handshake.server} v${s.handshake.version} on :${s.settings?.port}` : s.error ?? `not connected (port ${s.settings?.port})`;
  const ul = $("sessions");
  ul.innerHTML = "";
  if (!s.sessions.length) ul.innerHTML = '<li class="muted">none</li>';
  for (const x of s.sessions) {
    const li = document.createElement("li");
    li.textContent = `${x.id} \xB7 ${x.tabs} tab(s)${x.borrowed ? `, ${x.borrowed} borrowed` : ""}${x.controller ? ` \xB7 ${x.controller.name}` : ""}`;
    ul.appendChild(li);
  }
  $("hint").textContent = s.state !== "connected" ? "Start the daemon: `bctl daemon start` (or any bctl command)." : "";
}
async function refresh() {
  const s = await chrome.runtime.sendMessage({ type: "bctl.status" });
  if (s) render(s);
}
$("enabled").addEventListener("change", async (e) => {
  await chrome.storage.local.set({ enabled: e.target.checked });
  await chrome.runtime.sendMessage({ type: "bctl.settings.changed" });
  setTimeout(refresh, 300);
});
$("savePort").addEventListener("click", async () => {
  const port = Number($("port").value);
  if (!Number.isInteger(port) || port < 1 || port > 65535) return;
  await chrome.storage.local.set({ port });
  await chrome.runtime.sendMessage({ type: "bctl.settings.changed" });
  setTimeout(refresh, 500);
});
$("saveLabel").addEventListener("click", async () => {
  const label = $("label").value.trim();
  await chrome.storage.local.set({ label });
  await chrome.runtime.sendMessage({ type: "bctl.reconnect" });
  setTimeout(refresh, 800);
});
$("instance").addEventListener("click", () => navigator.clipboard?.writeText($("instance").textContent ?? ""));
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "bctl.status.push" && msg.status) render(msg.status);
});
void refresh();
setInterval(refresh, 2e3);
