// ../protocol/src/index.ts
var PROTOCOL_VERSION = "1.0";
var DEFAULT_WS_PORT = 52810;
var EXTENSION_CLIENT_ID = "browser-control-extension";
function isRequestFrame(f) {
  return !!f && typeof f === "object" && typeof f.method === "string" && typeof f.id === "string";
}
function isResponseFrame(f) {
  return !!f && typeof f === "object" && typeof f.id === "string" && !("method" in f) && ("result" in f || "error" in f);
}
function rpcError(code, message, data) {
  return data ? { code, message, data } : { code, message };
}
function browserFromUserAgent(ua, brands = []) {
  const chromium = /Chrome\/(\d+)/.exec(ua)?.[1];
  const b = brands.map((s) => s.toLowerCase());
  const probes = [
    [/Whale\/([0-9.]+)/, "whale"],
    [/Edg\/([0-9.]+)/, "edge"],
    [/OPR\/([0-9.]+)/, "opera"],
    [/Vivaldi\/([0-9.]+)/, "vivaldi"],
    [/YaBrowser\/([0-9.]+)/, "yandex"],
    [/SamsungBrowser\/([0-9.]+)/, "samsung"],
    [/Brave\/([0-9.]+)/, "brave"]
  ];
  for (const [re, name] of probes) {
    const m = re.exec(ua);
    if (m) return { name, version: m[1] ?? "", chromium, detected_by: "ua" };
  }
  for (const [needle, name] of [
    ["microsoft edge", "edge"],
    ["brave", "brave"],
    ["opera", "opera"],
    ["vivaldi", "vivaldi"],
    ["whale", "whale"],
    ["google chrome", "chrome"]
  ]) {
    if (b.some((x) => x.includes(needle))) return { name, version: chromium ?? "", chromium, detected_by: "brands" };
  }
  if (chromium) return { name: "chrome", version: chromium, chromium, detected_by: "ua" };
  return { name: "chromium", version: "unknown", detected_by: "ua" };
}

// src/cdp.ts
var CDP_VERSION = "1.3";
var MAX_BUFFER = 500;
var CdpError = class extends Error {
  constructor(message, reason) {
    super(message);
    this.reason = reason;
    this.name = "CdpError";
  }
};
var Cdp = class {
  attached = /* @__PURE__ */ new Set();
  attaching = /* @__PURE__ */ new Map();
  captures = /* @__PURE__ */ new Map();
  dialogListeners = /* @__PURE__ */ new Set();
  constructor() {
    chrome.debugger.onEvent.addListener((source, method, params) => {
      if (source.tabId === void 0) return;
      this.handleEvent(source.tabId, method, params);
    });
    chrome.debugger.onDetach.addListener((source) => {
      if (source.tabId !== void 0) {
        this.attached.delete(source.tabId);
      }
    });
  }
  isAttached(tabId) {
    return this.attached.has(tabId);
  }
  onDialog(l) {
    this.dialogListeners.add(l);
    return () => this.dialogListeners.delete(l);
  }
  capture(tabId) {
    let c = this.captures.get(tabId);
    if (!c) {
      c = { console: [], network: [], consoleSeq: 0, networkSeq: 0, pendingRequests: /* @__PURE__ */ new Map() };
      this.captures.set(tabId, c);
    }
    return c;
  }
  pendingDialog(tabId) {
    return this.captures.get(tabId)?.dialog;
  }
  async attach(tabId) {
    if (this.attached.has(tabId)) return;
    const inflight2 = this.attaching.get(tabId);
    if (inflight2) return inflight2;
    const p = (async () => {
      try {
        await chrome.debugger.attach({ tabId }, CDP_VERSION);
      } catch (e) {
        const msg = String(e?.message ?? e);
        if (/already attached/i.test(msg)) {
          throw new CdpError(`debugger already attached to tab ${tabId}: ${msg}`, "debugger_conflict");
        }
        if (/cannot attach|restricted|chrome:\/\/|not allowed|policy/i.test(msg)) throw new CdpError(msg, "cdp_attach_denied");
        throw new CdpError(msg, "cdp_attach_failed");
      }
      this.attached.add(tabId);
      this.capture(tabId);
      await Promise.allSettled([
        this.sendRaw(tabId, "Page.enable"),
        this.sendRaw(tabId, "Runtime.enable"),
        this.sendRaw(tabId, "Network.enable", { maxResourceBufferSize: 10 * 1024 * 1024, maxTotalBufferSize: 50 * 1024 * 1024 }),
        this.sendRaw(tabId, "Log.enable")
      ]);
    })();
    this.attaching.set(tabId, p);
    try {
      await p;
    } finally {
      this.attaching.delete(tabId);
    }
  }
  async detach(tabId) {
    if (!this.attached.has(tabId)) return;
    this.attached.delete(tabId);
    try {
      await chrome.debugger.detach({ tabId });
    } catch {
    }
  }
  forget(tabId) {
    this.attached.delete(tabId);
    this.captures.delete(tabId);
  }
  async send(tabId, method, params) {
    await this.attach(tabId);
    return this.sendRaw(tabId, method, params);
  }
  /**
   * Input commands block inside CDP while a JavaScript dialog is open. For actions that can open
   * one (click, press, Enter after fill) resolve as soon as a dialog appears on that tab instead;
   * the command itself completes later, once the agent decides the dialog.
   */
  async sendOrDialog(tabId, method, params) {
    await this.attach(tabId);
    const existing = this.pendingDialog(tabId);
    if (existing) return { dialog: existing };
    return new Promise((resolve) => {
      let settled = false;
      const off = this.onDialog((id, dialog) => {
        if (id !== tabId || !dialog || settled) return;
        settled = true;
        off();
        resolve({ dialog });
      });
      this.sendRaw(tabId, method, params).then(
        (result) => {
          if (settled) return;
          settled = true;
          off();
          resolve({ result });
        },
        (err) => {
          if (settled) return;
          settled = true;
          off();
          const d = this.pendingDialog(tabId);
          if (d) resolve({ dialog: d });
          else throw err;
        }
      );
    });
  }
  async sendRaw(tabId, method, params) {
    try {
      return await chrome.debugger.sendCommand({ tabId }, method, params);
    } catch (e) {
      const msg = String(e?.message ?? e);
      if (/not attached|detached/i.test(msg)) this.attached.delete(tabId);
      throw new CdpError(`${method}: ${msg}`, "cdp_command_failed");
    }
  }
  handleEvent(tabId, method, params) {
    const c = this.capture(tabId);
    const now = Date.now();
    switch (method) {
      case "Runtime.consoleAPICalled": {
        const args = params?.args ?? [];
        const text = args.map((a) => a.value !== void 0 ? typeof a.value === "string" ? a.value : JSON.stringify(a.value) : a.description ?? a.type ?? "").join(" ");
        const frame = params?.stackTrace?.callFrames?.[0];
        pushBounded(c.console, { seq: ++c.consoleSeq, ts: now, level: String(params?.type ?? "log"), text: clip(text), url: frame?.url, line: frame?.lineNumber });
        break;
      }
      case "Runtime.exceptionThrown": {
        const d = params?.exceptionDetails;
        pushBounded(c.console, { seq: ++c.consoleSeq, ts: now, level: "error", text: clip(d?.exception?.description ?? d?.text ?? "exception"), url: d?.url, line: d?.lineNumber });
        break;
      }
      case "Log.entryAdded": {
        const e = params?.entry;
        if (e) pushBounded(c.console, { seq: ++c.consoleSeq, ts: now, level: `${e.source ?? "log"}:${e.level ?? "info"}`, text: clip(e.text ?? ""), url: e.url, line: e.lineNumber });
        break;
      }
      case "Network.requestWillBeSent": {
        const req = params?.request;
        const id = String(params?.requestId);
        const seq = ++c.networkSeq;
        c.pendingRequests.set(id, { seq, start: now });
        pushBounded(c.network, { seq, ts: now, request_id: id, method: req?.method ?? "GET", url: clip(req?.url ?? "", 2048), resource_type: params?.type });
        break;
      }
      case "Network.responseReceived": {
        const id = String(params?.requestId);
        const resp = params?.response;
        const entry = c.network.find((e) => e.request_id === id);
        if (entry) {
          entry.status = resp?.status;
          entry.mime = resp?.mimeType;
        }
        break;
      }
      case "Network.loadingFinished":
      case "Network.loadingFailed": {
        const id = String(params?.requestId);
        const entry = c.network.find((e) => e.request_id === id);
        const p = c.pendingRequests.get(id);
        if (entry && p) entry.duration_ms = now - p.start;
        if (entry && method === "Network.loadingFailed") entry.failed = String(params?.errorText ?? "failed");
        c.pendingRequests.delete(id);
        break;
      }
      case "Page.javascriptDialogOpening": {
        c.dialog = {
          tab_id: tabId,
          type: params?.type ?? "alert",
          message: clip(String(params?.message ?? "")),
          default_prompt: params?.defaultPrompt,
          url: params?.url,
          opened_at: now
        };
        for (const l of this.dialogListeners) l(tabId, c.dialog);
        break;
      }
      case "Page.javascriptDialogClosed": {
        c.dialog = void 0;
        for (const l of this.dialogListeners) l(tabId, void 0);
        break;
      }
      default:
        break;
    }
  }
};
function pushBounded(arr, v) {
  arr.push(v);
  if (arr.length > MAX_BUFFER) arr.splice(0, arr.length - MAX_BUFFER);
}
function clip(s, n = 4096) {
  return s.length > n ? `${s.slice(0, n)}\u2026` : s;
}

// src/identity.ts
var EXTENSION_VERSION = true ? "1.0.0" : "0.0.0";
var BASE_WS = new URL(true ? "ws://127.0.0.1:52810" : `ws://127.0.0.1:${DEFAULT_WS_PORT}`);
async function loadSettings() {
  const got = await chrome.storage.local.get(["instanceId", "label", "port", "enabled"]);
  let instanceId = typeof got.instanceId === "string" ? got.instanceId : "";
  if (!instanceId) {
    instanceId = crypto.randomUUID().replace(/-/g, "").slice(0, 12);
    await chrome.storage.local.set({ instanceId });
  }
  const port = Number.isInteger(got.port) && got.port > 0 && got.port < 65536 ? got.port : Number(BASE_WS.port) || DEFAULT_WS_PORT;
  return {
    instanceId,
    label: typeof got.label === "string" ? got.label : "",
    port,
    enabled: got.enabled !== false
  };
}
function wsUrlForPort(port) {
  return `${BASE_WS.protocol}//${BASE_WS.hostname}:${port}${BASE_WS.pathname === "/" ? "" : BASE_WS.pathname}`;
}
async function detectBrowser() {
  const uaData = navigator.userAgentData;
  const brands = uaData?.brands?.map((b) => b.brand) ?? [];
  const meta = browserFromUserAgent(navigator.userAgent, brands);
  const brave = navigator.brave;
  if (brave?.isBrave) {
    try {
      if (await brave.isBrave()) return { ...meta, name: "brave", detected_by: "api" };
    } catch {
    }
  }
  return meta;
}

// src/sessions.ts
var SessionManager = class {
  sessions = /* @__PURE__ */ new Map();
  get(id) {
    return this.sessions.get(id);
  }
  byWindow(windowId) {
    for (const s of this.sessions.values()) if (s.windowId === windowId) return s;
    return void 0;
  }
  /** Session that controls a tab: tab lives in its Agent Window or is borrowed by it. */
  async owner(tabId) {
    for (const s of this.sessions.values()) if (s.borrowed.has(tabId)) return s;
    try {
      const tab = await chrome.tabs.get(tabId);
      if (tab.windowId !== void 0) return this.byWindow(tab.windowId);
    } catch {
    }
    return void 0;
  }
  async create(opts) {
    if (this.sessions.has(opts.id)) throw new Error(`session ${opts.id} already exists`);
    if (opts.incognito && !await chrome.extension.isAllowedIncognitoAccess()) {
      throw new Error("incognito access is not allowed for this extension; enable it in the browser's extension settings");
    }
    const win = await chrome.windows.create({
      url: "about:blank",
      focused: opts.focused ?? false,
      type: "normal",
      incognito: opts.incognito ?? false,
      ...opts.width ? { width: opts.width } : {},
      ...opts.height ? { height: opts.height } : {}
    });
    if (!win?.id) throw new Error("chrome.windows.create returned no window");
    let tabId = win.tabs?.[0]?.id ?? null;
    if (tabId == null) {
      const tabs = await chrome.tabs.query({ windowId: win.id });
      tabId = tabs[0]?.id ?? null;
    }
    const s = {
      id: opts.id,
      windowId: win.id,
      activeTabId: tabId,
      borrowed: /* @__PURE__ */ new Map(),
      createdAt: Date.now(),
      controller: opts.controller,
      incognito: opts.incognito ?? false
    };
    this.sessions.set(opts.id, s);
    return s;
  }
  /** Returns borrowed tabs, closes the Agent Window. */
  async destroy(id) {
    const s = this.sessions.get(id);
    if (!s) return { returned: [], closed: [] };
    this.sessions.delete(id);
    const returned = [];
    for (const tabId of Array.from(s.borrowed.keys())) {
      try {
        await this.returnTab(s, tabId);
        returned.push(tabId);
      } catch {
      }
    }
    const closed = [];
    try {
      const tabs = await chrome.tabs.query({ windowId: s.windowId });
      for (const t of tabs) if (t.id !== void 0) closed.push(t.id);
      await chrome.windows.remove(s.windowId);
    } catch {
    }
    return { returned, closed };
  }
  async borrowTab(s, tabId) {
    const tab = await chrome.tabs.get(tabId);
    if (tab.windowId === s.windowId) throw new Error("tab is already in the Agent Window");
    if (this.byWindow(tab.windowId)) throw new Error("tab belongs to another session's Agent Window");
    for (const other of this.sessions.values()) if (other.borrowed.has(tabId)) throw new Error(`tab ${tabId} is borrowed by session ${other.id}`);
    if (!!tab.incognito !== s.incognito) throw new Error("incognito mismatch between tab and session");
    const rec = { fromWindowId: tab.windowId, fromIndex: tab.index, wasActive: !!tab.active };
    await chrome.tabs.move(tabId, { windowId: s.windowId, index: -1 });
    await chrome.tabs.update(tabId, { active: true });
    s.borrowed.set(tabId, rec);
    s.activeTabId = tabId;
    return { ...rec, tab };
  }
  async returnTab(s, tabId) {
    const rec = s.borrowed.get(tabId);
    if (!rec) throw new Error(`tab ${tabId} is not borrowed by session ${s.id}`);
    s.borrowed.delete(tabId);
    let targetWindow = rec.fromWindowId;
    try {
      await chrome.windows.get(targetWindow);
    } catch {
      const wins = await chrome.windows.getAll({ windowTypes: ["normal"] });
      const candidate = wins.find((w) => w.id !== void 0 && !this.byWindow(w.id) && w.incognito === s.incognito);
      if (candidate?.id !== void 0) targetWindow = candidate.id;
      else {
        const created = await chrome.windows.create({ tabId, focused: false, incognito: s.incognito });
        if (s.activeTabId === tabId) s.activeTabId = null;
        return created?.id ?? -1;
      }
    }
    await chrome.tabs.move(tabId, { windowId: targetWindow, index: rec.fromIndex });
    if (rec.wasActive) await chrome.tabs.update(tabId, { active: true }).catch(() => {
    });
    if (s.activeTabId === tabId) s.activeTabId = null;
    return targetWindow;
  }
  async controlledTabs(s) {
    const inWindow = await chrome.tabs.query({ windowId: s.windowId }).catch(() => []);
    return inWindow;
  }
  /** Resolve the tab a tool should act on. */
  async resolveTab(s, tabId) {
    if (tabId !== void 0) {
      const tab2 = await chrome.tabs.get(tabId).catch(() => null);
      if (!tab2) throw new TabError("not_found", `tab ${tabId} not found`, "tab_not_found");
      if (tab2.windowId !== s.windowId && !s.borrowed.has(tabId)) {
        throw new TabError("permission_denied", `tab ${tabId} is not controlled by session ${s.id}; borrow it first`, "tab_not_controlled");
      }
      return tab2;
    }
    if (s.activeTabId != null) {
      const tab2 = await chrome.tabs.get(s.activeTabId).catch(() => null);
      if (tab2 && (tab2.windowId === s.windowId || s.borrowed.has(tab2.id))) return tab2;
    }
    const tabs = await chrome.tabs.query({ windowId: s.windowId, active: true }).catch(() => []);
    const tab = tabs[0];
    if (!tab?.id) throw new TabError("not_found", `session ${s.id} has no active tab`, "no_active_tab");
    s.activeTabId = tab.id;
    return tab;
  }
};
var TabError = class extends Error {
  constructor(code, message, reason) {
    super(message);
    this.code = code;
    this.reason = reason;
  }
};
function isRestrictedUrl(url) {
  if (!url) return false;
  return /^(chrome|edge|whale|brave|arc|dia|about|devtools|view-source|chrome-extension|chrome-untrusted):/i.test(url) && url !== "about:blank";
}

// src/keys.ts
var NAMED = {
  enter: { key: "Enter", code: "Enter", keyCode: 13, text: "\r" },
  return: { key: "Enter", code: "Enter", keyCode: 13, text: "\r" },
  tab: { key: "Tab", code: "Tab", keyCode: 9 },
  escape: { key: "Escape", code: "Escape", keyCode: 27 },
  esc: { key: "Escape", code: "Escape", keyCode: 27 },
  backspace: { key: "Backspace", code: "Backspace", keyCode: 8 },
  delete: { key: "Delete", code: "Delete", keyCode: 46 },
  space: { key: " ", code: "Space", keyCode: 32, text: " " },
  arrowup: { key: "ArrowUp", code: "ArrowUp", keyCode: 38 },
  arrowdown: { key: "ArrowDown", code: "ArrowDown", keyCode: 40 },
  arrowleft: { key: "ArrowLeft", code: "ArrowLeft", keyCode: 37 },
  arrowright: { key: "ArrowRight", code: "ArrowRight", keyCode: 39 },
  up: { key: "ArrowUp", code: "ArrowUp", keyCode: 38 },
  down: { key: "ArrowDown", code: "ArrowDown", keyCode: 40 },
  left: { key: "ArrowLeft", code: "ArrowLeft", keyCode: 37 },
  right: { key: "ArrowRight", code: "ArrowRight", keyCode: 39 },
  home: { key: "Home", code: "Home", keyCode: 36 },
  end: { key: "End", code: "End", keyCode: 35 },
  pageup: { key: "PageUp", code: "PageUp", keyCode: 33 },
  pagedown: { key: "PageDown", code: "PageDown", keyCode: 34 },
  insert: { key: "Insert", code: "Insert", keyCode: 45 },
  capslock: { key: "CapsLock", code: "CapsLock", keyCode: 20 }
};
for (let i = 1; i <= 12; i++) NAMED[`f${i}`] = { key: `F${i}`, code: `F${i}`, keyCode: 111 + i };
var MODS = { alt: 1, option: 1, ctrl: 2, control: 2, meta: 4, cmd: 4, command: 4, super: 4, shift: 8 };
function parseKeyCombo(combo) {
  const parts = combo.split("+").map((p) => p.trim()).filter(Boolean);
  if (parts.length === 0) throw new Error("empty key combo");
  let modifiers = 0;
  let last = parts[parts.length - 1];
  for (const p of parts.slice(0, -1)) {
    const m = MODS[p.toLowerCase()];
    if (m === void 0) throw new Error(`unknown modifier "${p}"`);
    modifiers |= m;
  }
  if (combo.endsWith("++")) last = "+";
  const named = NAMED[last.toLowerCase()];
  if (named) return { modifiers, spec: named };
  if (last.length === 1) {
    const ch = last;
    const upper = ch.toUpperCase();
    const isLetter = /[a-z]/i.test(ch);
    const isDigit = /[0-9]/.test(ch);
    const code = isLetter ? `Key${upper}` : isDigit ? `Digit${ch}` : "";
    const keyCode = isLetter || isDigit ? upper.charCodeAt(0) : ch.charCodeAt(0);
    const text = modifiers & (2 | 4) ? void 0 : ch;
    return { modifiers, spec: { key: modifiers & 8 && isLetter ? upper : ch, code, keyCode, text } };
  }
  throw new Error(`unknown key "${last}"`);
}

// src/page-agent.ts
function pageAgent(op, args) {
  const g = globalThis;
  const docKey = `${location.href}#${document.documentElement.__bctlDoc ?? 0}`;
  if (!g.__bctl || g.__bctl.docKey !== docKey) {
    g.__bctl = { refs: /* @__PURE__ */ new Map(), byEl: /* @__PURE__ */ new WeakMap(), next: 1, observationId: "", docKey };
  }
  const S = g.__bctl;
  const INTERACTIVE_TAGS = /* @__PURE__ */ new Set(["a", "button", "input", "select", "textarea", "summary", "option", "label"]);
  const INTERACTIVE_ROLES = /* @__PURE__ */ new Set([
    "button",
    "link",
    "checkbox",
    "radio",
    "textbox",
    "combobox",
    "listbox",
    "option",
    "menuitem",
    "menuitemcheckbox",
    "menuitemradio",
    "tab",
    "switch",
    "slider",
    "spinbutton",
    "searchbox",
    "treeitem",
    "gridcell",
    "row"
  ]);
  const LANDMARK_TAGS = {
    nav: "navigation",
    main: "main",
    header: "banner",
    footer: "contentinfo",
    aside: "complementary",
    form: "form",
    section: "region",
    article: "article",
    dialog: "dialog",
    table: "table",
    ul: "list",
    ol: "list",
    li: "listitem",
    img: "img",
    h1: "heading",
    h2: "heading",
    h3: "heading",
    h4: "heading",
    h5: "heading",
    h6: "heading",
    p: "paragraph",
    video: "video",
    audio: "audio",
    iframe: "iframe",
    details: "group",
    fieldset: "group",
    legend: "legend"
  };
  function isVisible(el) {
    if (!(el instanceof HTMLElement || el instanceof SVGElement)) return false;
    if (el.getAttribute("aria-hidden") === "true") return false;
    const cs = getComputedStyle(el);
    if (cs.display === "none" || cs.visibility === "hidden" || cs.opacity === "0") return false;
    if (el instanceof HTMLElement && el.hidden) return false;
    const r = el.getBoundingClientRect();
    if (r.width === 0 && r.height === 0 && !(el.tagName === "OPTION")) return false;
    return true;
  }
  function norm(s) {
    return (s ?? "").replace(/\s+/g, " ").trim();
  }
  function roleOf(el) {
    const explicit = norm(el.getAttribute("role")).split(" ")[0];
    if (explicit) return explicit;
    const tag = el.tagName.toLowerCase();
    if (tag === "a") return el.hasAttribute("href") ? "link" : "generic";
    if (tag === "input") {
      const t = (el.type || "text").toLowerCase();
      if (t === "checkbox") return "checkbox";
      if (t === "radio") return "radio";
      if (t === "submit" || t === "button" || t === "reset" || t === "image") return "button";
      if (t === "range") return "slider";
      if (t === "number") return "spinbutton";
      if (t === "search") return "searchbox";
      if (t === "hidden") return "hidden";
      if (t === "file") return "filebutton";
      return "textbox";
    }
    if (tag === "select") return el.multiple ? "listbox" : "combobox";
    if (tag === "textarea") return "textbox";
    if (tag === "button" || tag === "summary") return "button";
    if (tag === "option") return "option";
    if (tag === "label") return "label";
    if (el.isContentEditable && el.getAttribute("contenteditable") !== null) return "textbox";
    if (LANDMARK_TAGS[tag]) return LANDMARK_TAGS[tag];
    return "generic";
  }
  function labelText(el) {
    const id = el.getAttribute("id");
    if (id) {
      const lab = document.querySelector(`label[for="${CSS.escape(id)}"]`);
      if (lab) return norm(lab.textContent);
    }
    const wrap = el.closest("label");
    if (wrap) return norm(wrap.textContent);
    return "";
  }
  function nameOf(el, role) {
    const aria = norm(el.getAttribute("aria-label"));
    if (aria) return aria;
    const by = el.getAttribute("aria-labelledby");
    if (by) {
      const parts = by.split(/\s+/).map((i) => norm(document.getElementById(i)?.textContent)).filter(Boolean);
      if (parts.length) return parts.join(" ");
    }
    const tag = el.tagName.toLowerCase();
    if (tag === "input" || tag === "select" || tag === "textarea") {
      const l = labelText(el);
      if (l) return l;
      const ph = norm(el.getAttribute("placeholder"));
      if (ph) return ph;
      const v = el.value;
      if (role === "button" && v) return norm(v);
      return norm(el.getAttribute("name") || el.getAttribute("title"));
    }
    if (tag === "img") return norm(el.getAttribute("alt") || el.getAttribute("title"));
    const title = norm(el.getAttribute("title"));
    const txt = norm(el.innerText ?? el.textContent);
    if (txt) return txt.length > 120 ? `${txt.slice(0, 117)}\u2026` : txt;
    if (title) return title;
    const img = el.querySelector("img[alt], svg[aria-label], [aria-label]");
    if (img) return norm(img.getAttribute("alt") || img.getAttribute("aria-label"));
    return "";
  }
  function isInteractive(el, role) {
    const tag = el.tagName.toLowerCase();
    if (INTERACTIVE_TAGS.has(tag) && role !== "generic" && role !== "hidden" && role !== "label") return true;
    if (INTERACTIVE_ROLES.has(role)) return true;
    if (el.isContentEditable) return true;
    const ti = el.getAttribute("tabindex");
    if (ti !== null && Number(ti) >= 0) return true;
    if (el.hasAttribute("onclick")) return true;
    const cs = getComputedStyle(el);
    if (cs.cursor === "pointer" && tag !== "body" && tag !== "html") {
      const parent = el.parentElement;
      if (parent && getComputedStyle(parent).cursor === "pointer") return false;
      return true;
    }
    return false;
  }
  function refFor(el) {
    let r = S.byEl.get(el);
    if (!r) {
      r = `e${S.next++}`;
      S.byEl.set(el, r);
    }
    S.refs.set(r, el);
    return r;
  }
  function extras(el, role) {
    const parts = [];
    const tag = el.tagName.toLowerCase();
    if (role === "link") {
      const href = el.getAttribute("href");
      if (href && !href.startsWith("javascript:")) parts.push(`href=${JSON.stringify(href.length > 80 ? `${href.slice(0, 77)}\u2026` : href)}`);
    }
    if (role === "heading") parts.push(`level=${tag.length === 2 && /h[1-6]/.test(tag) ? tag[1] : el.getAttribute("aria-level") ?? "?"}`);
    if (tag === "input" || tag === "textarea") {
      const inp = el;
      const t = (inp.type || "text").toLowerCase();
      if (t === "checkbox" || t === "radio") parts.push(inp.checked ? "checked" : "unchecked");
      else if (t !== "password" && inp.value) parts.push(`value=${JSON.stringify(inp.value.length > 60 ? `${inp.value.slice(0, 57)}\u2026` : inp.value)}`);
      if (t === "password") parts.push("type=password");
      if (inp.required) parts.push("required");
    }
    if (tag === "select") {
      const sel = el;
      const opts = Array.from(sel.options).slice(0, 12).map((o) => o.selected ? `*${o.value}` : o.value);
      parts.push(`options=[${opts.join(",")}${sel.options.length > 12 ? ",\u2026" : ""}]`);
    }
    if (role === "checkbox" || role === "radio" || role === "switch") {
      const ac = el.getAttribute("aria-checked");
      if (ac && tag !== "input") parts.push(ac === "true" ? "checked" : "unchecked");
    }
    if (el.getAttribute("aria-expanded")) parts.push(`expanded=${el.getAttribute("aria-expanded")}`);
    if (el.getAttribute("aria-selected") === "true") parts.push("selected");
    if (el.disabled || el.getAttribute("aria-disabled") === "true") parts.push("disabled");
    return parts.length ? ` [${parts.join(" ")}]` : "";
  }
  function snapshot(mode, maxChars, rootSel) {
    let root = document.body ?? document.documentElement;
    if (rootSel) {
      const r = resolveTarget(rootSel);
      if (r) root = r;
    }
    S.observationId = `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
    S.refs.clear();
    const lines = [];
    let refCount = 0;
    let chars = 0;
    let truncated = false;
    const seenText = /* @__PURE__ */ new Set();
    function push(depth, line) {
      if (chars + line.length + 1 > maxChars) {
        truncated = true;
        return false;
      }
      lines.push(`${"  ".repeat(depth)}${line}`);
      chars += line.length + 1;
      return true;
    }
    function walk(el, depth) {
      if (truncated) return;
      if (!isVisible(el)) return;
      const tag = el.tagName.toLowerCase();
      if (tag === "script" || tag === "style" || tag === "noscript" || tag === "template") return;
      const role = roleOf(el);
      const interactive = isInteractive(el, role);
      let emitted = false;
      if (interactive) {
        const ref = refFor(el);
        refCount++;
        push(depth, `- ${role} ${JSON.stringify(nameOf(el, role))} @${ref}${extras(el, role)}`);
        emitted = true;
        if (tag === "select" || tag === "textarea" || tag === "input" || tag === "button" || role === "link") return;
      } else if (role === "heading" || role === "img" || role === "dialog" || role === "iframe") {
        const name = nameOf(el, role);
        if (name || role === "iframe") {
          const ref = role === "iframe" ? ` @${refFor(el)}` : "";
          push(depth, `- ${role} ${JSON.stringify(name)}${ref}${extras(el, role)}`);
          emitted = true;
          if (role !== "dialog") return;
        }
      } else if (["navigation", "main", "banner", "contentinfo", "complementary", "form", "table", "list", "listitem", "region", "article", "group"].includes(role)) {
        const name = norm(el.getAttribute("aria-label")) || (role === "region" ? "" : "");
        if (role !== "listitem" && role !== "group") {
          push(depth, `- ${role}${name ? ` ${JSON.stringify(name)}` : ""}`);
          emitted = true;
        }
      }
      const childDepth = emitted ? depth + 1 : depth;
      for (const node of Array.from(el.childNodes)) {
        if (truncated) return;
        if (node.nodeType === Node.TEXT_NODE) {
          const t = norm(node.textContent);
          if (!t) continue;
          if (mode === "interactive" && t.length < 2) continue;
          const key = t.slice(0, 200);
          if (seenText.has(key)) continue;
          seenText.add(key);
          const clipped = mode === "interactive" && t.length > 240 ? `${t.slice(0, 237)}\u2026` : t;
          push(childDepth, `- text: ${JSON.stringify(clipped)}`);
        } else if (node.nodeType === Node.ELEMENT_NODE) {
          walk(node, childDepth);
        }
      }
      const sr = el.shadowRoot;
      if (sr) for (const c of Array.from(sr.children)) walk(c, childDepth);
    }
    walk(root, 0);
    return { text: lines.join("\n"), refCount, truncated };
  }
  function resolveTarget(target) {
    const m = /^@?e(\d+)$/.exec(target.trim());
    if (m) {
      const el = S.refs.get(`e${m[1]}`);
      return el && el.isConnected ? el : null;
    }
    try {
      return document.querySelector(target);
    } catch {
      return null;
    }
  }
  function centerOf(el) {
    const rects = Array.from(el.getClientRects()).filter((r2) => r2.width > 0 && r2.height > 0);
    const r = rects[0] ?? el.getBoundingClientRect();
    const x = r.left + Math.min(r.width / 2, Math.max(1, r.width / 2));
    const y = r.top + Math.min(r.height / 2, Math.max(1, r.height / 2));
    const inView = x >= 0 && y >= 0 && x <= innerWidth && y <= innerHeight;
    return { x, y, width: r.width, height: r.height, visible: inView && r.width > 0 && r.height > 0 };
  }
  function describe(el) {
    const role = roleOf(el);
    return `${role} ${JSON.stringify(nameOf(el, role))}`;
  }
  function hitOk(el, x, y) {
    const top = document.elementFromPoint(x, y);
    if (!top) return false;
    if (top === el || el.contains(top) || top.contains(el)) return true;
    const topRoot = top.getRootNode().host;
    if (topRoot && (topRoot === el || el.contains(topRoot))) return true;
    return false;
  }
  function setNativeValue(el, value) {
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, "value");
    if (desc?.set) desc.set.call(el, value);
    else el.value = value;
  }
  switch (op) {
    case "page_info":
      return { url: location.href, title: document.title, ready: document.readyState, scrollX, scrollY, innerWidth, innerHeight, observation_id: S.observationId };
    case "snapshot": {
      const r = snapshot(args.mode ?? "interactive", args.max_chars ?? 4e4, args.root);
      return { ...r, url: location.href, title: document.title, observation_id: S.observationId };
    }
    case "find": {
      const q = String(args.query ?? "").toLowerCase();
      const limit = args.limit ?? 20;
      const out = [];
      const all = document.querySelectorAll("*");
      for (const el of Array.from(all)) {
        if (out.length >= limit) break;
        if (!isVisible(el)) continue;
        const role = roleOf(el);
        if (!isInteractive(el, role) && role !== "heading") continue;
        const name = nameOf(el, role);
        const hay = `${role} ${name} ${el.id} ${el.getAttribute("placeholder") ?? ""}`.toLowerCase();
        if (hay.includes(q)) out.push({ ref: refFor(el), role, name });
      }
      if (!S.observationId) S.observationId = `${Date.now().toString(36)}`;
      return { matches: out, observation_id: S.observationId };
    }
    case "resolve": {
      const el = resolveTarget(args.target);
      if (!el) return { found: false };
      if (args.scroll !== false) {
        try {
          el.scrollIntoView({ block: "center", inline: "center", behavior: "instant" });
        } catch {
        }
      }
      const c = centerOf(el);
      const tag = el.tagName.toLowerCase();
      const disabled = el.disabled === true;
      return { found: true, ...c, tag, description: describe(el), disabled, covered: c.visible ? !hitOk(el, c.x, c.y) : false };
    }
    case "get_html": {
      const el = args.target ? resolveTarget(args.target) : document.documentElement;
      if (!el) return { found: false };
      const html = args.outer === false ? el.innerHTML : el.outerHTML;
      const max = args.max_chars ?? 2e5;
      return { found: true, html: html.slice(0, max), truncated: html.length > max };
    }
    case "get_text": {
      const el = args.target ? resolveTarget(args.target) : document.body;
      if (!el) return { found: false };
      const text = (el.innerText ?? el.textContent ?? "").replace(/\n{3,}/g, "\n\n").trim();
      const max = args.max_chars ?? 1e5;
      return { found: true, url: location.href, title: document.title, text: text.slice(0, max), truncated: text.length > max };
    }
    case "scroll": {
      const el = args.target ? resolveTarget(args.target) : null;
      const scroller = el ?? window;
      if (args.to === "top") scroller.scrollTo?.({ top: 0 }) ?? (scroller.scrollTop = 0);
      else if (args.to === "bottom") {
        if (scroller === window) window.scrollTo({ top: document.documentElement.scrollHeight });
        else scroller.scrollTop = scroller.scrollHeight;
      } else {
        const dx = args.delta_x ?? 0;
        const dy = args.delta_y ?? 0;
        if (scroller === window) window.scrollBy({ left: dx, top: dy });
        else {
          scroller.scrollLeft += dx;
          scroller.scrollTop += dy;
        }
      }
      const sx = scroller === window ? window.scrollX : scroller.scrollLeft;
      const sy = scroller === window ? window.scrollY : scroller.scrollTop;
      const atBottom = scroller === window ? Math.ceil(window.innerHeight + window.scrollY) >= document.documentElement.scrollHeight - 1 : Math.ceil(scroller.clientHeight + scroller.scrollTop) >= scroller.scrollHeight - 1;
      return { scroll_x: sx, scroll_y: sy, at_bottom: atBottom };
    }
    case "scroll_to": {
      const el = resolveTarget(args.target);
      if (!el) return { found: false };
      el.scrollIntoView({ block: args.block ?? "center", behavior: "instant" });
      return { found: true, ...centerOf(el) };
    }
    case "focus": {
      const el = resolveTarget(args.target);
      if (!el) return { found: false };
      el.focus?.();
      return { found: true, focused: document.activeElement === el };
    }
    case "prepare_fill": {
      const el = resolveTarget(args.target);
      if (!el) return { found: false };
      const tag = el.tagName.toLowerCase();
      const editable = el.isContentEditable;
      if (!(tag === "input" || tag === "textarea" || editable)) {
        const inner = el.querySelector("input, textarea, [contenteditable=''], [contenteditable='true']");
        if (!inner) return { found: true, fillable: false, description: describe(el) };
        return pageAgent("prepare_fill", { target: `@${refFor(inner)}` });
      }
      if (el.disabled || el.readOnly) return { found: true, fillable: false, reason: "disabled_or_readonly" };
      el.scrollIntoView({ block: "center", behavior: "instant" });
      el.focus();
      if (tag === "input" || tag === "textarea") {
        const inp = el;
        try {
          inp.select();
        } catch {
        }
        const t = (inp.type || "text").toLowerCase();
        return { found: true, fillable: true, kind: t, ref: refFor(el), native_date: ["date", "time", "datetime-local", "month", "week", "color", "range", "file"].includes(t) };
      }
      const sel = getSelection();
      const range = document.createRange();
      range.selectNodeContents(el);
      sel?.removeAllRanges();
      sel?.addRange(range);
      return { found: true, fillable: true, kind: "contenteditable", ref: refFor(el) };
    }
    case "fill_dom": {
      const el = resolveTarget(args.target);
      if (!el) return { found: false };
      const tag = el.tagName.toLowerCase();
      if (tag === "input" || tag === "textarea") {
        const inp = el;
        inp.focus();
        setNativeValue(inp, String(args.value));
        inp.dispatchEvent(new Event("input", { bubbles: true }));
        inp.dispatchEvent(new Event("change", { bubbles: true }));
        return { found: true, value: inp.value };
      }
      if (el.isContentEditable) {
        el.focus();
        el.textContent = String(args.value);
        el.dispatchEvent(new InputEvent("input", { bubbles: true, data: String(args.value), inputType: "insertText" }));
        return { found: true, value: el.textContent };
      }
      return { found: true, fillable: false };
    }
    case "read_value": {
      const el = resolveTarget(args.target);
      if (!el) return { found: false };
      const v = el.value ?? el.textContent;
      return { found: true, value: v };
    }
    case "click_dom": {
      const el = resolveTarget(args.target);
      if (!el) return { found: false };
      el.scrollIntoView({ block: "center", behavior: "instant" });
      const c = centerOf(el);
      const init = { bubbles: true, cancelable: true, clientX: c.x, clientY: c.y, button: 0 };
      el.dispatchEvent(new PointerEvent("pointerdown", init));
      el.dispatchEvent(new MouseEvent("mousedown", init));
      el.focus?.();
      el.dispatchEvent(new PointerEvent("pointerup", init));
      el.dispatchEvent(new MouseEvent("mouseup", init));
      el.click();
      return { found: true };
    }
    case "check_dom": {
      const el = resolveTarget(args.target);
      if (!el) return { found: false };
      const want = !!args.checked;
      if (el.tagName.toLowerCase() === "input" && (el.type === "checkbox" || el.type === "radio")) {
        if (el.checked !== want) el.click();
        return { found: true, checked: el.checked, changed: el.checked === want };
      }
      const cur = el.getAttribute("aria-checked") === "true";
      if (cur !== want) el.click();
      return { found: true, checked: el.getAttribute("aria-checked") === "true" };
    }
    case "select_dom": {
      const el = resolveTarget(args.target);
      if (!el) return { found: false };
      if (el.tagName.toLowerCase() !== "select") return { found: true, is_select: false };
      const values = args.values ?? [];
      const selected = [];
      const missing = [];
      for (const o of Array.from(el.options)) o.selected = false;
      for (const v of values) {
        const opt = Array.from(el.options).find((o) => o.value === v) ?? Array.from(el.options).find((o) => norm(o.textContent) === v);
        if (opt) {
          opt.selected = true;
          selected.push(opt.value);
          if (!el.multiple) break;
        } else missing.push(v);
      }
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      return { found: true, is_select: true, selected, missing };
    }
    case "wait_state": {
      const el = resolveTarget(args.target);
      const state = args.state ?? "visible";
      if (state === "attached") return { matched: !!el };
      if (state === "detached") return { matched: !el };
      if (state === "visible") return { matched: !!el && isVisible(el) };
      if (state === "hidden") return { matched: !el || !isVisible(el) };
      return { matched: false };
    }
    default:
      return { error: `unknown op ${op}` };
  }
}

// src/tools.ts
var ToolError = class extends Error {
  constructor(rpc) {
    super(rpc.message);
    this.rpc = rpc;
  }
};
function fail(code, message, reason, hint) {
  throw new ToolError(rpcError(code, message, { ...reason ? { reason } : {}, ...hint ? { hint } : {} }));
}
function buildTools(deps) {
  const { sessions: sessions2, cdp: cdp2 } = deps;
  function session(p) {
    const s = sessions2.get(p?.session_id);
    if (!s) fail("not_found", `session ${p?.session_id} not found`, "session_not_found", "start a session with `bctl session start --json`");
    return s;
  }
  async function tab(p) {
    const s = session(p);
    try {
      const t = await sessions2.resolveTab(s, p.tab_id);
      return { s, tab: t, tabId: t.id };
    } catch (e) {
      if (e instanceof TabError) fail(e.code, e.message, e.reason);
      throw e;
    }
  }
  function assertScriptable(t) {
    if (isRestrictedUrl(t.url)) fail("unsupported", `tab ${t.id} is a restricted page (${t.url}); navigate to an http(s) page first`, "restricted_tab_url");
  }
  async function assertNoDialog(tabId) {
    const d = cdp2.pendingDialog(tabId);
    if (d) fail("dialog_pending", `a ${d.type} dialog is open: ${JSON.stringify(d.message)}`, "dialog_pending", "decide it with `bctl dialog accept|dismiss` before continuing; never repeat the action");
  }
  async function page(t, op, args = {}) {
    assertScriptable(t);
    await assertNoDialog(t.id);
    let results;
    try {
      results = await withTimeout(
        chrome.scripting.executeScript({ target: { tabId: t.id }, func: pageAgent, args: [op, args], world: "ISOLATED" }),
        15e3,
        `page script ${op}`
      );
    } catch (e) {
      const msg = String(e?.message ?? e);
      if (/cannot access|restricted|chrome:\/\/|web store|extensions gallery/i.test(msg)) fail("unsupported", `cannot script tab ${t.id}: ${msg}`, "restricted_tab_url");
      if (/timed out/i.test(msg)) {
        const d = cdp2.pendingDialog(t.id);
        if (d) fail("dialog_pending", `a ${d.type} dialog is open: ${JSON.stringify(d.message)}`, "dialog_pending");
        fail("timeout", msg, "renderer_timeout", "the page may be hung or showing a native dialog; try `bctl dialog status` or reload");
      }
      fail("internal", `page script failed: ${msg}`, "script_failed");
    }
    const r = results[0]?.result;
    if (r && typeof r === "object" && "error" in r) fail("internal", String(r.error));
    return r;
  }
  async function resolveTarget(t, target) {
    const r = await page(t, "resolve", { target });
    if (!r.found) {
      const isRef = /^@?e\d+$/.test(target.trim());
      fail("not_found", `${isRef ? "ref" : "selector"} ${target} not found in tab ${t.id}`, isRef ? "ref_not_found" : "selector_not_found", isRef ? "refs expire on navigation; run `bctl snapshot` again" : "check the selector with `bctl snapshot` or `bctl find`");
    }
    return r;
  }
  async function navigatedTo(t) {
    const after = await chrome.tabs.get(t.id).catch(() => null);
    return after?.url && after.url !== t.url ? after.url : void 0;
  }
  async function cdpMouse(tabId, x, y, opts) {
    const button = opts.button ?? "left";
    const clickCount = opts.clickCount ?? 1;
    const modifiers = opts.modifiers ?? 0;
    if ((await cdp2.sendOrDialog(tabId, "Input.dispatchMouseEvent", { type: "mouseMoved", x, y, modifiers })).dialog) return true;
    for (let i = 1; i <= clickCount; i++) {
      if ((await cdp2.sendOrDialog(tabId, "Input.dispatchMouseEvent", { type: "mousePressed", x, y, button, clickCount: i, modifiers })).dialog) return true;
      if ((await cdp2.sendOrDialog(tabId, "Input.dispatchMouseEvent", { type: "mouseReleased", x, y, button, clickCount: i, modifiers })).dialog) return true;
    }
    return false;
  }
  async function pressKey(tabId, combo) {
    const { modifiers, spec } = parseKeyCombo(combo);
    const base = { modifiers, key: spec.key, code: spec.code, windowsVirtualKeyCode: spec.keyCode, nativeVirtualKeyCode: spec.keyCode };
    if ((await cdp2.sendOrDialog(tabId, "Input.dispatchKeyEvent", { type: spec.text ? "keyDown" : "rawKeyDown", ...base, ...spec.text ? { text: spec.text, unmodifiedText: spec.text } : {} })).dialog) return true;
    if ((await cdp2.sendOrDialog(tabId, "Input.dispatchKeyEvent", { type: "keyUp", ...base })).dialog) return true;
    return false;
  }
  function cdpUnavailable(e) {
    return e instanceof CdpError && (e.reason === "cdp_attach_denied" || e.reason === "cdp_attach_failed" || e.reason === "debugger_conflict");
  }
  async function waitTabComplete(tabId, timeoutMs, waitUntil) {
    if (waitUntil === "none") return "complete";
    const deadline = Date.now() + timeoutMs;
    await sleep(80);
    while (Date.now() < deadline) {
      const t = await chrome.tabs.get(tabId).catch(() => null);
      if (!t) fail("not_found", `tab ${tabId} closed during navigation`, "tab_closed");
      if (t.status === "complete") {
        if (waitUntil === "domcontentloaded") return "complete";
        return "complete";
      }
      if (cdp2.pendingDialog(tabId)) return "complete";
      await sleep(100);
    }
    return "timeout";
  }
  const tools2 = {
    // ----------------------------------------------------------------------- sessions
    async "tool.session_start"(raw) {
      const p = raw;
      let s;
      try {
        s = await sessions2.create({ id: p.session_id, focused: p.focused, width: p.width, height: p.height, incognito: p.incognito, controller: p.controller });
      } catch (e) {
        fail("permission_denied", String(e.message), "window_create_failed");
      }
      if (s.activeTabId != null) deps.notifyControlled(s.activeTabId, s.id);
      return { agent_window_id: s.windowId, active_tab_id: s.activeTabId ?? -1 };
    },
    async "tool.session_stop"(raw) {
      const p = raw;
      const s = sessions2.get(p.session_id);
      if (!s) return { returned_tabs: [], closed_tabs: [] };
      const tabs = await sessions2.controlledTabs(s);
      for (const t of tabs) if (t.id !== void 0) await cdp2.detach(t.id);
      for (const id of s.borrowed.keys()) {
        await cdp2.detach(id);
        deps.notifyControlled(id, null);
      }
      const r = await sessions2.destroy(p.session_id);
      for (const id of r.returned) deps.notifyControlled(id, null);
      return { returned_tabs: r.returned, closed_tabs: r.closed };
    },
    // ----------------------------------------------------------------------- tabs / window
    async "tool.tab_list"(raw) {
      const p = raw;
      const s = session(p);
      const scope = p.scope ?? "all";
      const all = await chrome.tabs.query({});
      const out = [];
      for (const t of all) {
        if (t.id === void 0 || t.windowId === void 0) continue;
        const inAgent = t.windowId === s.windowId;
        const otherAgent = !inAgent && sessions2.byWindow(t.windowId) !== void 0;
        if (otherAgent) continue;
        const tabScope = inAgent ? "agent" : "user";
        if (scope === "agent" && tabScope !== "agent") continue;
        if (scope === "user" && tabScope !== "user") continue;
        out.push({ tab_id: t.id, window_id: t.windowId, title: t.title, url: t.url, active: t.active, scope: tabScope, ...s.borrowed.has(t.id) ? { borrowed: true } : {} });
      }
      return { tabs: out, active_tab_id: s.activeTabId ?? void 0 };
    },
    async "tool.tab_create"(raw) {
      const p = raw;
      const s = session(p);
      const t = await chrome.tabs.create({ windowId: s.windowId, url: p.url ?? "about:blank", active: p.active ?? true });
      if (t.id === void 0) fail("internal", "tab create returned no id");
      if (p.active ?? true) s.activeTabId = t.id;
      deps.notifyControlled(t.id, s.id);
      return { tab_id: t.id };
    },
    async "tool.tab_close"(raw) {
      const p = raw;
      const { s, tabId } = await tab(p);
      if (s.borrowed.has(tabId)) fail("permission_denied", `tab ${tabId} is borrowed; return it instead of closing`, "borrowed_tab_close");
      await cdp2.detach(tabId);
      await chrome.tabs.remove(tabId);
      if (s.activeTabId === tabId) s.activeTabId = null;
      return { tab_id: tabId };
    },
    async "tool.tab_select"(raw) {
      const p = raw;
      const { s, tabId } = await tab(p);
      await chrome.tabs.update(tabId, { active: true });
      s.activeTabId = tabId;
      return { tab_id: tabId };
    },
    async "tool.tab_borrow"(raw) {
      const p = raw;
      const s = session(p);
      try {
        const r = await sessions2.borrowTab(s, p.tab_id);
        deps.notifyControlled(p.tab_id, s.id);
        return { tab_id: p.tab_id, from_window_id: r.fromWindowId, title: r.tab.title, url: r.tab.url };
      } catch (e) {
        fail("permission_denied", String(e.message), "borrow_failed");
      }
    },
    async "tool.tab_return"(raw) {
      const p = raw;
      const s = session(p);
      try {
        await cdp2.detach(p.tab_id);
        const w = await sessions2.returnTab(s, p.tab_id);
        deps.notifyControlled(p.tab_id, null);
        return { tab_id: p.tab_id, window_id: w };
      } catch (e) {
        fail("not_found", String(e.message), "return_failed");
      }
    },
    async "tool.window_resize"(raw) {
      const p = raw;
      const s = session(p);
      await chrome.windows.update(s.windowId, { width: p.width, height: p.height, state: "normal" });
      const w = await chrome.windows.get(s.windowId);
      return { window_id: s.windowId, width: w.width, height: w.height };
    },
    // ----------------------------------------------------------------------- navigation
    async "tool.navigate"(raw) {
      const p = raw;
      const { tab: t, tabId } = await tab(p);
      await assertNoDialog(tabId);
      let url = p.url.trim();
      if (!/^[a-z][a-z0-9+.-]*:/i.test(url)) url = `https://${url}`;
      await chrome.tabs.update(tabId, { url });
      const status = await waitTabComplete(tabId, p.timeout_ms ?? 3e4, p.wait_until ?? "load");
      const after = await chrome.tabs.get(tabId);
      void t;
      return { tab_id: tabId, url: after.url ?? url, title: after.title, status };
    },
    async "tool.navigate_back"(raw) {
      const p = raw;
      const { tabId } = await tab(p);
      await chrome.tabs.goBack(tabId);
      const status = await waitTabComplete(tabId, p.timeout_ms ?? 15e3, "load");
      const after = await chrome.tabs.get(tabId);
      return { tab_id: tabId, url: after.url ?? "", title: after.title, status };
    },
    async "tool.navigate_forward"(raw) {
      const p = raw;
      const { tabId } = await tab(p);
      await chrome.tabs.goForward(tabId);
      const status = await waitTabComplete(tabId, p.timeout_ms ?? 15e3, "load");
      const after = await chrome.tabs.get(tabId);
      return { tab_id: tabId, url: after.url ?? "", title: after.title, status };
    },
    async "tool.reload"(raw) {
      const p = raw;
      const { tabId } = await tab(p);
      await chrome.tabs.reload(tabId);
      const status = await waitTabComplete(tabId, p.timeout_ms ?? 3e4, "load");
      const after = await chrome.tabs.get(tabId);
      return { tab_id: tabId, url: after.url ?? "", title: after.title, status };
    },
    // ----------------------------------------------------------------------- reads
    async "tool.snapshot"(raw) {
      const p = raw;
      const { tab: t, tabId } = await tab(p);
      const r = await page(t, "snapshot", { mode: p.mode ?? "interactive", max_chars: p.max_chars ?? 4e4, root: p.root });
      const dialog = cdp2.pendingDialog(tabId);
      return { tab_id: tabId, url: r.url, title: r.title, observation_id: r.observation_id, text: r.text, ref_count: r.refCount, truncated: r.truncated, ...dialog ? { dialog } : {} };
    },
    async "tool.find"(raw) {
      const p = raw;
      const { tab: t, tabId } = await tab(p);
      const r = await page(t, "find", { query: p.query, limit: p.limit ?? 20 });
      return { tab_id: tabId, observation_id: r.observation_id, matches: r.matches };
    },
    async "tool.get_html"(raw) {
      const p = raw;
      const { tab: t, tabId } = await tab(p);
      const r = await page(t, "get_html", { target: p.target, outer: p.outer, max_chars: p.max_chars });
      if (!r.found) fail("not_found", `target ${p.target} not found`, "selector_not_found");
      return { tab_id: tabId, html: r.html, truncated: r.truncated };
    },
    async "tool.get_text"(raw) {
      const p = raw;
      const { tab: t, tabId } = await tab(p);
      const r = await page(t, "get_text", { target: p.target, max_chars: p.max_chars });
      if (!r.found) fail("not_found", `target ${p.target} not found`, "selector_not_found");
      return { tab_id: tabId, url: r.url, title: r.title, text: r.text, truncated: r.truncated };
    },
    async "tool.screenshot"(raw) {
      const p = raw;
      const { tab: t, tabId } = await tab(p);
      const format = p.format ?? "png";
      let clip2;
      if (p.target) {
        const r = await resolveTarget(t, p.target);
        clip2 = { x: Math.max(0, r.x - r.width / 2), y: Math.max(0, r.y - r.height / 2), width: Math.max(1, r.width), height: Math.max(1, r.height), scale: 1 };
      }
      try {
        if (p.full_page && !clip2) {
          const m = await cdp2.send(tabId, "Page.getLayoutMetrics");
          const { width, height } = m.cssContentSize;
          const cap = 16384;
          clip2 = { x: 0, y: 0, width: Math.min(width, cap), height: Math.min(height, cap), scale: 1 };
        }
        const r = await cdp2.send(tabId, "Page.captureScreenshot", {
          format,
          ...format === "jpeg" ? { quality: p.quality ?? 80 } : {},
          ...clip2 ? { clip: clip2, captureBeyondViewport: true } : {},
          fromSurface: true
        });
        const size = clip2 ? { width: Math.round(clip2.width), height: Math.round(clip2.height) } : await viewportSize(t);
        return { tab_id: tabId, format, ...size, data: r.data, via: "cdp" };
      } catch (e) {
        if (!cdpUnavailable(e)) throw e;
        if (!t.active) await chrome.tabs.update(tabId, { active: true });
        const dataUrl = await chrome.tabs.captureVisibleTab(t.windowId, { format, ...format === "jpeg" ? { quality: p.quality ?? 80 } : {} });
        const size = await viewportSize(t);
        return { tab_id: tabId, format, ...size, data: dataUrl.replace(/^data:[^,]+,/, ""), via: "tabs_api" };
      }
    },
    // ----------------------------------------------------------------------- input
    async "tool.click"(raw) {
      const p = raw;
      const { tab: t, tabId } = await tab(p);
      const r = await resolveTarget(t, p.target);
      if (r.disabled) fail("unsupported", `${r.description} is disabled`, "target_disabled");
      if (!r.visible) fail("unsupported", `${r.description} is not in the viewport after scrolling`, "target_hidden");
      let via = "cdp";
      if (p.dom) via = "dom";
      else {
        try {
          const mods = (p.modifiers ?? []).reduce((acc, m) => acc | ({ alt: 1, ctrl: 2, meta: 4, shift: 8 }[m] ?? 0), 0);
          await cdpMouse(tabId, r.x, r.y, { button: p.button ?? "left", clickCount: p.click_count ?? 1, modifiers: mods });
        } catch (e) {
          if (!cdpUnavailable(e)) throw e;
          via = "dom";
        }
      }
      if (via === "dom") await page(t, "click_dom", { target: p.target });
      await sleep(50);
      const dialog = cdp2.pendingDialog(tabId);
      return { tab_id: tabId, target: p.target, via, navigated_to: await navigatedTo(t), ...dialog ? { dialog } : {} };
    },
    async "tool.hover"(raw) {
      const p = raw;
      const { tab: t, tabId } = await tab(p);
      const r = await resolveTarget(t, p.target);
      try {
        await cdp2.send(tabId, "Input.dispatchMouseEvent", { type: "mouseMoved", x: r.x, y: r.y });
        return { tab_id: tabId, target: p.target, via: "cdp" };
      } catch (e) {
        if (!cdpUnavailable(e)) throw e;
        fail("unsupported", "hover requires the debugger (CDP) and it is unavailable for this tab", "cdp_unavailable");
      }
    },
    async "tool.fill"(raw) {
      const p = raw;
      const { tab: t, tabId } = await tab(p);
      const prep = await page(t, "prepare_fill", { target: p.target });
      if (!prep.found) fail("not_found", `target ${p.target} not found`, "ref_not_found");
      if (!prep.fillable) fail("unsupported", `${prep.description ?? p.target} is not fillable (${prep.reason ?? "not an input"})`, "target_not_fillable");
      let via = "cdp";
      if (prep.native_date) via = "dom";
      else {
        try {
          await cdp2.send(tabId, "Input.insertText", { text: p.value });
          if (p.value === "") {
            await pressKey(tabId, "Delete");
          }
          const check = await page(t, "read_value", { target: p.target });
          if (check.found && typeof check.value === "string" && check.value !== p.value && prep.kind !== "contenteditable") via = "dom";
        } catch (e) {
          if (!cdpUnavailable(e)) throw e;
          via = "dom";
        }
      }
      if (via === "dom") await page(t, "fill_dom", { target: p.target, value: p.value });
      if (p.submit) {
        try {
          await pressKey(tabId, "Enter");
        } catch (e) {
          if (!cdpUnavailable(e)) throw e;
          await page(t, "click_dom", { target: `${p.target}` });
        }
        await sleep(150);
      }
      return { tab_id: tabId, target: p.target, via, navigated_to: await navigatedTo(t) };
    },
    async "tool.type"(raw) {
      const p = raw;
      const { tabId } = await tab(p);
      await assertNoDialog(tabId);
      try {
        if (p.delay_ms && p.delay_ms > 0) {
          for (const ch of p.text) {
            await cdp2.send(tabId, "Input.insertText", { text: ch });
            await sleep(p.delay_ms);
          }
        } else await cdp2.send(tabId, "Input.insertText", { text: p.text });
      } catch (e) {
        if (!cdpUnavailable(e)) throw e;
        fail("unsupported", "type requires the debugger (CDP); use `bctl fill` on a target instead", "cdp_unavailable");
      }
      return { tab_id: tabId, target: "focused", via: "cdp" };
    },
    async "tool.press"(raw) {
      const p = raw;
      const { tab: t, tabId } = await tab(p);
      await assertNoDialog(tabId);
      if (p.target) await page(t, "focus", { target: p.target });
      try {
        await pressKey(tabId, p.key);
      } catch (e) {
        if (e instanceof CdpError && !cdpUnavailable(e)) throw e;
        if (!(e instanceof CdpError)) fail("invalid_params", String(e.message), "bad_key");
        fail("unsupported", "press requires the debugger (CDP) and it is unavailable for this tab", "cdp_unavailable");
      }
      await sleep(50);
      const dialog = cdp2.pendingDialog(tabId);
      return { tab_id: tabId, target: p.target ?? "focused", via: "cdp", navigated_to: await navigatedTo(t), ...dialog ? { dialog } : {} };
    },
    async "tool.select"(raw) {
      const p = raw;
      const { tab: t, tabId } = await tab(p);
      const r = await page(t, "select_dom", { target: p.target, values: p.values });
      if (!r.found) fail("not_found", `target ${p.target} not found`, "ref_not_found");
      if (!r.is_select) fail("unsupported", `${p.target} is not a <select>; click the control and choose an option instead`, "target_not_select");
      if (r.missing?.length) fail("not_found", `option(s) not found: ${r.missing.join(", ")}`, "option_not_found", "use the option's value attribute or exact visible label");
      return { tab_id: tabId, target: p.target, via: "dom", selected: r.selected };
    },
    async "tool.check"(raw) {
      const p = raw;
      const { tab: t, tabId } = await tab(p);
      const r = await page(t, "check_dom", { target: p.target, checked: p.checked });
      if (!r.found) fail("not_found", `target ${p.target} not found`, "ref_not_found");
      return { tab_id: tabId, target: p.target, via: "dom", checked: r.checked };
    },
    async "tool.scroll"(raw) {
      const p = raw;
      const { tab: t, tabId } = await tab(p);
      const r = await page(t, "scroll", { target: p.target, delta_x: p.delta_x, delta_y: p.delta_y, to: p.to });
      return { tab_id: tabId, scroll_x: r.scroll_x, scroll_y: r.scroll_y, at_bottom: r.at_bottom };
    },
    async "tool.scroll_to"(raw) {
      const p = raw;
      const { tab: t, tabId } = await tab(p);
      const r = await page(t, "scroll_to", { target: p.target });
      if (!r.found) fail("not_found", `target ${p.target} not found`, "ref_not_found");
      return { tab_id: tabId, target: p.target, via: "dom" };
    },
    // ----------------------------------------------------------------------- script / debugging
    async "tool.evaluate"(raw) {
      const p = raw;
      const { tab: t, tabId } = await tab(p);
      assertScriptable(t);
      await assertNoDialog(tabId);
      try {
        const r = await cdp2.send(tabId, "Runtime.evaluate", {
          expression: p.expression,
          returnByValue: true,
          awaitPromise: true,
          userGesture: true,
          timeout: p.timeout_ms ?? 15e3
        });
        if (r.exceptionDetails) fail("internal", r.exceptionDetails.exception?.description ?? r.exceptionDetails.text ?? "evaluation threw", "evaluate_threw");
        return { tab_id: tabId, value: r.result.value ?? r.result.description ?? null, type: r.result.type };
      } catch (e) {
        if (!cdpUnavailable(e)) throw e;
        const results = await chrome.scripting.executeScript({
          target: { tabId },
          world: p.world === "isolated" ? "ISOLATED" : "MAIN",
          func: (src) => {
            try {
              const v = new Function(`return (${src})`)();
              return { ok: true, value: v, type: typeof v };
            } catch (err) {
              return { ok: false, error: String(err?.message ?? err) };
            }
          },
          args: [p.expression]
        });
        const r = results[0]?.result;
        if (!r?.ok) fail("internal", r?.error ?? "evaluation failed", "evaluate_threw");
        return { tab_id: tabId, value: r.value ?? null, type: r.type ?? "undefined" };
      }
    },
    async "tool.console"(raw) {
      const p = raw;
      const { tab: t, tabId } = await tab(p);
      assertScriptable(t);
      let capturing = true;
      try {
        await cdp2.attach(tabId);
      } catch {
        capturing = false;
      }
      const c = cdp2.capture(tabId);
      let entries = c.console.filter((e) => (p.since_seq ? e.seq > p.since_seq : true) && (p.level ? e.level.includes(p.level) : true));
      if (p.limit) entries = entries.slice(-p.limit);
      if (p.clear) c.console.length = 0;
      return { tab_id: tabId, entries, capturing };
    },
    async "tool.network"(raw) {
      const p = raw;
      const { tab: t, tabId } = await tab(p);
      assertScriptable(t);
      let capturing = true;
      try {
        await cdp2.attach(tabId);
      } catch {
        capturing = false;
      }
      const c = cdp2.capture(tabId);
      let body;
      if (p.body_for) {
        try {
          const r = await cdp2.send(tabId, "Network.getResponseBody", { requestId: p.body_for });
          const max = 512 * 1024;
          body = { request_id: p.body_for, base64: r.base64Encoded, body: r.body.slice(0, max), truncated: r.body.length > max };
        } catch (e) {
          fail("not_found", `response body unavailable for ${p.body_for}: ${e.message}`, "body_unavailable", "bodies are only retained for requests observed while capturing");
        }
      }
      let entries = c.network.filter((e) => (p.since_seq ? e.seq > p.since_seq : true) && (p.filter ? e.url.includes(p.filter) || e.method === p.filter : true));
      if (p.limit) entries = entries.slice(-p.limit);
      if (p.clear) c.network.length = 0;
      return { tab_id: tabId, entries, capturing, ...body ? { body } : {} };
    },
    // ----------------------------------------------------------------------- waits
    async "tool.wait_for_element"(raw) {
      const p = raw;
      const { tab: t, tabId } = await tab(p);
      const start = Date.now();
      const deadline = start + (p.timeout_ms ?? 1e4);
      while (true) {
        const r = await page(t, "wait_state", { target: p.target, state: p.state ?? "visible" }).catch(() => ({ matched: false }));
        if (r.matched) return { tab_id: tabId, matched: true, elapsed_ms: Date.now() - start };
        if (Date.now() >= deadline) return { tab_id: tabId, matched: false, elapsed_ms: Date.now() - start };
        await sleep(150);
      }
    },
    async "tool.wait_for_navigation"(raw) {
      const p = raw;
      const { tabId } = await tab(p);
      const deadline = Date.now() + (p.timeout_ms ?? 15e3);
      while (Date.now() < deadline) {
        const t2 = await chrome.tabs.get(tabId).catch(() => null);
        if (!t2) fail("not_found", `tab ${tabId} closed`, "tab_closed");
        const urlOk = p.url_includes ? (t2.url ?? "").includes(p.url_includes) : true;
        if (urlOk && t2.status === "complete") return { tab_id: tabId, url: t2.url ?? "", reached: "load" };
        await sleep(100);
      }
      const t = await chrome.tabs.get(tabId).catch(() => null);
      return { tab_id: tabId, url: t?.url ?? "", reached: "timeout" };
    },
    // ----------------------------------------------------------------------- dialogs
    async "tool.dialog_status"(raw) {
      const p = raw;
      const { tabId } = await tab(p);
      const d = cdp2.pendingDialog(tabId);
      return { tab_id: tabId, ...d ? { dialog: d } : {} };
    },
    async "tool.dialog_handle"(raw) {
      const p = raw;
      const { tabId } = await tab(p);
      const d = cdp2.pendingDialog(tabId);
      if (!d) return { tab_id: tabId, handled: false };
      await cdp2.send(tabId, "Page.handleJavaScriptDialog", { accept: p.accept, ...p.text !== void 0 ? { promptText: p.text } : {} });
      return { tab_id: tabId, handled: true };
    },
    // ----------------------------------------------------------------------- misc
    async "tool.cookies"(raw) {
      const p = raw;
      const { tab: t, tabId } = await tab(p);
      const url = t.url ?? "";
      const cookies = await chrome.cookies.getAll(p.domain ? { domain: p.domain } : { url });
      return { tab_id: tabId, cookies: cookies.map((c) => ({ name: c.name, domain: c.domain, path: c.path, secure: c.secure, http_only: c.httpOnly, expires: c.expirationDate })) };
    },
    async "tool.pdf"(raw) {
      const p = raw;
      const { tabId } = await tab(p);
      try {
        const r = await cdp2.send(tabId, "Page.printToPDF", { landscape: p.landscape ?? false, printBackground: true });
        return { tab_id: tabId, data: r.data };
      } catch (e) {
        if (cdpUnavailable(e)) fail("unsupported", "pdf export requires the debugger (CDP)", "cdp_unavailable");
        throw e;
      }
    }
  };
  return tools2;
}
async function viewportSize(t) {
  return { width: t.width ?? 0, height: t.height ?? 0 };
}
function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}
function withTimeout(p, ms, what) {
  return new Promise((resolve, reject) => {
    const t = setTimeout(() => reject(new Error(`${what} timed out after ${ms}ms`)), ms);
    p.then(
      (v) => {
        clearTimeout(t);
        resolve(v);
      },
      (e) => {
        clearTimeout(t);
        reject(e);
      }
    );
  });
}

// src/transport.ts
var WsTransport = class {
  ws = null;
  url;
  _state = "disconnected";
  messageListeners = /* @__PURE__ */ new Set();
  stateListeners = /* @__PURE__ */ new Set();
  openListeners = /* @__PURE__ */ new Set();
  backoffMs = 1e3;
  reconnectTimer = null;
  wantOpen = false;
  lastError = null;
  constructor(url) {
    this.url = url;
  }
  get state() {
    return this._state;
  }
  get error() {
    return this.lastError;
  }
  setUrl(url) {
    if (url === this.url) return;
    this.url = url;
    if (this.wantOpen) {
      this.closeSocket();
      this.connect();
    }
  }
  connect() {
    this.wantOpen = true;
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) return;
    this.clearTimer();
    this.setState("connecting");
    let ws;
    try {
      ws = new WebSocket(this.url);
    } catch (e) {
      this.lastError = String(e);
      this.scheduleReconnect();
      return;
    }
    this.ws = ws;
    ws.onopen = () => {
      if (this.ws !== ws) return;
      this.backoffMs = 1e3;
      this.lastError = null;
      this.setState("connected");
      for (const l of this.openListeners) l();
    };
    ws.onmessage = (ev) => {
      if (this.ws !== ws) return;
      let frame;
      try {
        frame = JSON.parse(typeof ev.data === "string" ? ev.data : "");
      } catch {
        return;
      }
      for (const l of this.messageListeners) l(frame);
    };
    ws.onerror = () => {
      this.lastError = `cannot reach ${this.url}`;
    };
    ws.onclose = (ev) => {
      if (this.ws !== ws) return;
      this.ws = null;
      if (ev.reason) this.lastError = ev.reason;
      this.setState("disconnected");
      if (this.wantOpen) this.scheduleReconnect();
    };
  }
  disconnect() {
    this.wantOpen = false;
    this.clearTimer();
    this.closeSocket();
    this.setState("disconnected");
  }
  send(frame) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) throw new Error("transport not connected");
    this.ws.send(JSON.stringify(frame));
  }
  onMessage(l) {
    this.messageListeners.add(l);
    return () => this.messageListeners.delete(l);
  }
  onStateChange(l) {
    this.stateListeners.add(l);
    return () => this.stateListeners.delete(l);
  }
  onOpen(l) {
    this.openListeners.add(l);
    return () => this.openListeners.delete(l);
  }
  /** Called from an alarm: if we should be open but are not, try now. */
  poke() {
    if (this.wantOpen && (!this.ws || this.ws.readyState === WebSocket.CLOSED)) {
      this.clearTimer();
      this.connect();
    }
  }
  closeSocket() {
    const ws = this.ws;
    this.ws = null;
    if (ws) {
      ws.onclose = null;
      ws.onmessage = null;
      try {
        ws.close();
      } catch {
      }
    }
  }
  scheduleReconnect() {
    this.clearTimer();
    const delay = this.backoffMs;
    this.backoffMs = Math.min(this.backoffMs * 2, 3e4);
    this.reconnectTimer = setTimeout(() => this.connect(), delay);
  }
  clearTimer() {
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    this.reconnectTimer = null;
  }
  setState(s) {
    if (this._state === s) return;
    this._state = s;
    for (const l of this.stateListeners) l(s);
  }
};

// src/background.ts
var HEARTBEAT_MS = 2e4;
var KEEPALIVE_ALARM = "bctl-keepalive";
var sessions = new SessionManager();
var cdp = new Cdp();
var settings = null;
var transport = null;
var handshake = null;
var handshakeError = null;
var heartbeat = null;
var browserMeta = { name: "chromium", version: "unknown" };
var inflight = /* @__PURE__ */ new Map();
var tools = buildTools({
  sessions,
  cdp,
  notifyControlled(tabId, sessionId) {
    chrome.tabs.sendMessage(tabId, { type: "bctl.control", sessionId }).catch(() => {
    });
  }
});
async function ensureTransport() {
  settings = await loadSettings();
  browserMeta = await detectBrowser();
  const url = wsUrlForPort(settings.port);
  if (!transport) {
    transport = new WsTransport(url);
    transport.onOpen(() => void onOpen());
    transport.onMessage((f) => void onFrame(f));
    transport.onStateChange((s) => {
      if (s !== "connected") {
        handshake = null;
        stopHeartbeat();
        if (s === "disconnected") void onDisconnected();
      }
      void broadcastStatus();
    });
  } else transport.setUrl(url);
  if (settings.enabled) transport.connect();
  else transport.disconnect();
}
async function onOpen() {
  if (!transport || !settings) return;
  handshakeError = null;
  const params = {
    client: EXTENSION_CLIENT_ID,
    version: EXTENSION_VERSION,
    protocol_version: PROTOCOL_VERSION,
    instance_id: settings.instanceId,
    browser: browserMeta,
    label: settings.label
  };
  const id = `hs-${Math.random().toString(36).slice(2, 10)}`;
  const done = new Promise((resolve) => {
    const off = transport.onMessage((f) => {
      if (isResponseFrame(f) && f.id === id) {
        off();
        if ("error" in f) {
          handshakeError = `${f.error.code}: ${f.error.message}`;
          transport?.disconnect();
          setTimeout(() => transport?.connect(), 1e4);
        } else {
          handshake = f.result;
          startHeartbeat();
        }
        resolve();
      }
    });
    setTimeout(() => {
      off();
      resolve();
    }, 1e4);
  });
  transport.send({ id, method: "system.handshake", params });
  await done;
  void broadcastStatus();
}
async function onDisconnected() {
  for (const id of Array.from(sessions.sessions.keys())) {
    await tools["tool.session_stop"]({ session_id: id }).catch(() => {
    });
  }
}
function startHeartbeat() {
  stopHeartbeat();
  heartbeat = setInterval(() => {
    try {
      transport?.send({ event: "system.heartbeat" });
    } catch {
    }
  }, HEARTBEAT_MS);
}
function stopHeartbeat() {
  if (heartbeat) clearInterval(heartbeat);
  heartbeat = null;
}
function emit(event, payload) {
  try {
    transport?.send({ event, payload });
  } catch {
  }
}
async function onFrame(f) {
  if (!isRequestFrame(f)) return;
  const { id, method, params } = f;
  if (method === "cancel") {
    const target = params?.rpc_id;
    if (target) inflight.get(target)?.abort();
    reply(id, { cancelled: !!target && inflight.has(target) });
    return;
  }
  if (method === "system.ping") {
    reply(id, { pong: true, ts: Date.now() });
    return;
  }
  const handler = tools[method];
  if (!handler) {
    replyError(id, rpcError("unknown_method", `extension does not implement ${method}`));
    return;
  }
  const ac = new AbortController();
  inflight.set(id, ac);
  try {
    const result = await handler(params);
    reply(id, result ?? {});
  } catch (e) {
    replyError(id, toRpcError(e));
  } finally {
    inflight.delete(id);
  }
}
function toRpcError(e) {
  if (e instanceof ToolError) return e.rpc;
  const msg = String(e?.message ?? e);
  if (/No tab with id|No window with id/i.test(msg)) return rpcError("not_found", msg, { reason: "tab_not_found" });
  if (/Cannot access|cannot be scripted|chrome:\/\/|Extensions gallery/i.test(msg)) return rpcError("unsupported", msg, { reason: "restricted_tab_url" });
  if (/Debugger is not attached|Another debugger|Cannot attach/i.test(msg)) return rpcError("cdp_failed", msg, { reason: "cdp_attach_failed" });
  return rpcError("internal", msg);
}
function reply(id, result) {
  try {
    transport?.send({ id, result });
  } catch {
  }
}
function replyError(id, error) {
  try {
    transport?.send({ id, error });
  } catch {
  }
}
chrome.windows.onRemoved.addListener((windowId) => {
  const s = sessions.byWindow(windowId);
  if (!s) return;
  sessions.sessions.delete(s.id);
  for (const tabId of s.borrowed.keys()) {
    cdp.forget(tabId);
  }
  emit("session.window_closed", { session_id: s.id, window_id: windowId });
});
chrome.tabs.onRemoved.addListener((tabId) => {
  cdp.forget(tabId);
  for (const s of sessions.sessions.values()) {
    s.borrowed.delete(tabId);
    if (s.activeTabId === tabId) s.activeTabId = null;
  }
});
chrome.tabs.onActivated.addListener(({ tabId, windowId }) => {
  const s = sessions.byWindow(windowId);
  if (s) s.activeTabId = tabId;
});
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.status !== "complete") return;
  void (async () => {
    const s = await sessions.owner(tabId);
    if (s) chrome.tabs.sendMessage(tabId, { type: "bctl.control", sessionId: s.id, controller: s.controller }).catch(() => {
    });
    void tab;
  })();
});
cdp.onDialog((tabId, dialog) => {
  void (async () => {
    const s = await sessions.owner(tabId);
    if (s) emit("dialog.changed", { session_id: s.id, tab_id: tabId, dialog: dialog ?? null });
  })();
});
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    switch (msg.type) {
      case "bctl.status":
        sendResponse(await statusSnapshot());
        break;
      case "bctl.settings.changed":
        await ensureTransport();
        sendResponse({ ok: true });
        break;
      case "bctl.reconnect":
        transport?.disconnect();
        await ensureTransport();
        sendResponse({ ok: true });
        break;
      case "bctl.user_interrupt": {
        const sid = String(msg.sessionId ?? "");
        emit("session.user_interrupt", { session_id: sid, tab_id: sender.tab?.id });
        sendResponse({ ok: true });
        break;
      }
      case "bctl.whoami": {
        const tabId = sender.tab?.id;
        const s = tabId !== void 0 ? await sessions.owner(tabId) : void 0;
        sendResponse(s ? { sessionId: s.id, controller: s.controller } : { sessionId: null });
        break;
      }
      default:
        sendResponse({ error: "unknown message" });
    }
  })().catch((e) => sendResponse({ error: String(e) }));
  return true;
});
async function statusSnapshot() {
  const list = [];
  for (const s of sessions.sessions.values()) {
    const tabs = await sessions.controlledTabs(s);
    list.push({ id: s.id, windowId: s.windowId, tabs: tabs.length, borrowed: s.borrowed.size, controller: s.controller });
  }
  return {
    state: transport?.state ?? "disconnected",
    error: handshakeError ?? transport?.error ?? null,
    handshake,
    browser: browserMeta,
    settings,
    version: EXTENSION_VERSION,
    sessions: list
  };
}
async function broadcastStatus() {
  const snap = await statusSnapshot();
  chrome.runtime.sendMessage({ type: "bctl.status.push", status: snap }).catch(() => {
  });
  const color = snap.state === "connected" && handshake ? "#22c55e" : snap.state === "connecting" ? "#f59e0b" : "#9ca3af";
  const text = snap.state === "connected" && handshake ? snap.sessions.length ? String(snap.sessions.length) : "\u25CF" : snap.state === "connecting" ? "\u2026" : "";
  await chrome.action.setBadgeBackgroundColor({ color }).catch(() => {
  });
  await chrome.action.setBadgeText({ text }).catch(() => {
  });
}
chrome.alarms.create(KEEPALIVE_ALARM, { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name !== KEEPALIVE_ALARM) return;
  if (!transport) void ensureTransport();
  else transport.poke();
  void broadcastStatus();
});
chrome.runtime.onStartup.addListener(() => void ensureTransport());
chrome.runtime.onInstalled.addListener(() => void ensureTransport());
void ensureTransport();
